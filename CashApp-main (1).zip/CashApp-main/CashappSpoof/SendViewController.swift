//
//  SendViewController.swift
//  CashappSpoof

import UIKit

class SendViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        overrideUserInterfaceStyle = .dark
        view.backgroundColor = .black
        setupUI()
    }

    func setupUI() {
        // Amount display
        let amountLabel = UILabel()
        amountLabel.text = "$0"
        amountLabel.textColor = .white
        amountLabel.font = UIFont.systemFont(ofSize: 48, weight: .bold)
        amountLabel.textAlignment = .center
        amountLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(amountLabel)

        // Number pad (1-9, ., 0, <)
        let buttonTitles = [
            ["1", "2", "3"],
            ["4", "5", "6"],
            ["7", "8", "9"],
            [".", "0", "<"]
        ]

        let buttonSize: CGFloat = 70
        let spacing: CGFloat = 12
        let totalWidth = buttonSize * 3 + spacing * 2
        let startX = (view.bounds.width - totalWidth) / 2

        for rowIndex in 0..<buttonTitles.count {
            let row = buttonTitles[rowIndex]
            for colIndex in 0..<row.count {
                let button = UIButton(type: .system)
                button.setTitle(row[colIndex], for: .normal)
                button.setTitleColor(.white, for: .normal)
                button.titleLabel?.font = UIFont.systemFont(ofSize: 28, weight: .medium)
                button.backgroundColor = UIColor(white: 0.15, alpha: 1)
                button.layer.cornerRadius = buttonSize / 2
                button.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(button)

                let x = startX + CGFloat(colIndex) * (buttonSize + spacing)
                let y: CGFloat = 200 + CGFloat(rowIndex) * (buttonSize + spacing)

                NSLayoutConstraint.activate([
                    button.widthAnchor.constraint(equalToConstant: buttonSize),
                    button.heightAnchor.constraint(equalToConstant: buttonSize),
                    button.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: x),
                    button.topAnchor.constraint(equalTo: view.topAnchor, constant: y)
                ])
            }
        }

        // Bottom buttons: Pool, Request, Pay
        let bottomTitles = ["Pool", "Request", "Pay"]
        let bottomWidth: CGFloat = 100
        let bottomSpacing: CGFloat = 20
        let totalBottomWidth = bottomWidth * 3 + bottomSpacing * 2
        let bottomStartX = (view.bounds.width - totalBottomWidth) / 2
        let bottomY: CGFloat = 200 + 4 * (buttonSize + spacing) + 20

        for (index, title) in bottomTitles.enumerated() {
            let button = UIButton(type: .system)
            button.setTitle(title, for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
            button.backgroundColor = title == "Pay" ? .systemGreen : UIColor(white: 0.2, alpha: 1)
            button.layer.cornerRadius = 12
            button.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(button)

            let x = bottomStartX + CGFloat(index) * (bottomWidth + bottomSpacing)
            NSLayoutConstraint.activate([
                button.widthAnchor.constraint(equalToConstant: bottomWidth),
                button.heightAnchor.constraint(equalToConstant: 50),
                button.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: x),
                button.topAnchor.constraint(equalTo: view.topAnchor, constant: bottomY)
            ])
        }

        // Bottom icons: $ and 🛒
        let icons = ["$", "🛒"]
        let iconSize: CGFloat = 40
        let iconSpacing: CGFloat = 40
        let totalIconWidth = iconSize * 2 + iconSpacing
        let iconStartX = (view.bounds.width - totalIconWidth) / 2
        let iconY = bottomY + 70

        for (index, icon) in icons.enumerated() {
            let label = UILabel()
            label.text = icon
            label.textColor = .gray
            label.font = UIFont.systemFont(ofSize: 28)
            label.textAlignment = .center
            label.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(label)

            let x = iconStartX + CGFloat(index) * (iconSize + iconSpacing)
            NSLayoutConstraint.activate([
                label.widthAnchor.constraint(equalToConstant: iconSize),
                label.heightAnchor.constraint(equalToConstant: iconSize),
                label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: x),
                label.topAnchor.constraint(equalTo: view.topAnchor, constant: iconY)
            ])
        }

        // Layout for amount label
        NSLayoutConstraint.activate([
            amountLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            amountLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60)
        ])
    }
}